package org.javaro.lecture;
import org.javaro.lecture.Car; import org.javaro.lecture.Rentcar; import org.javaro.lecture.Customer;
public class Project {
	public static void main(String[] args ) {
		Rentcar myRC = new Rentcar("렌트카");
		Car car1 = new Car("K5"); Car car2 = new Car("GENESIS");
		Car car3 = new Car("그랜저"); Car car4 = new Car("미니컨버터블");
		Car car5 = new Car("BMW 430i"); Car car6 = new Car("벤츠 c클래스");
		Car car7 = new Car("머스탱"); Car car8 = new Car("레이");
		Car car9 = new Car("모닝"); Car car10 = new Car("아반뗴");
		car1.setPrice("20000"); car2.setPrice("100000");
		car3.setPrice("30000"); car4.setPrice("40000");
		car5.setPrice("60000"); car6.setPrice("70000");
		car7.setPrice("80000"); car8.setPrice("10000");
		car9.setPrice("10000"); car10.setPrice("20000");
		
		
		Customer cus1 = new Customer();
		Customer cus2 = new Customer();
		Customer cus3 = new Customer();
		Customer cus4 = new Customer();
		cus1.setName("이준"); cus2.setName("수호");
		cus3.setName("시우"); cus4.setName("선우");
		cus1.setAge("23세"); cus2.setAge("25세");
		cus3.setAge("32세"); cus4.setAge("28세");
		
		myRC.addCar(car1); myRC.addCar(car2);
		myRC.addCar(car3); myRC.addCar(car4);
		myRC.addCar(car5); myRC.addCar(car6);
		myRC.addCar(car7); myRC.addCar(car8);
		myRC.addCar(car9); myRC.addCar(car10);
		myRC.addCustomer(cus1); myRC.addCustomer(cus2);
		myRC.addCustomer(cus3); myRC.addCustomer(cus4);
		
		System.out.println("렌트카 관리 시스템 생성");
		myRC.printStatus();
		System.out.println("K5을 수호가 렌트");
		myRC.checkOut(car1, cus2);
		myRC.printStatus();
		System.out.println("K5 반납");
		myRC.checkIn(car1);
		System.out.println("GENESIS을 이준이 렌트");
		myRC.checkOut(car2, cus1);
		myRC.printStatus();
		System.out.println("BMW 430i을 수호가 렌트");
		myRC.checkOut(car5, cus2);
		myRC.printStatus();
		System.out.println("머스탱을 시우가 렌트");
		myRC.checkOut(car7, cus3);
		myRC.printStatus();
		System.out.println("GENESIS 반납");
		myRC.checkIn(car2);
		System.out.println("머스탱 반납");
		myRC.checkIn(car7);
	}
}