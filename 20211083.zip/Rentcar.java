package org.javaro.lecture;
import java.util.ArrayList; import org.javaro.lecture.Car; import org.javaro.lecture.Customer;
public class Rentcar {
	public String companyName; public ArrayList<Car> cars; public ArrayList<Customer> customers;
	public Rentcar(String companyName) {
		this.companyName = companyName; cars = new ArrayList<Car>(); customers = new ArrayList<Customer>();
	}
	public String getCompanyName() {
		return this.companyName;	}
	public ArrayList<Car> getCars() {
		return this.cars;	}
	public ArrayList<Customer> getCustomers() {
		return this.customers;	}
	public void addCar(Car car) {
		this.cars.add(car);	}
	public void removeCar(Car car) {
		this.cars.remove(car);	}
	public void addCustomer(Customer customer) {
		this.customers.add(customer);	}
	public void removeCustomer(Customer customer) {
		this.customers.remove(customer);
	}
public boolean checkOut(Car car, Customer customer) {
	if(car.getCustomer() == null)
		
	{
		car.setCustomer(customer);
		return true;
	} else {
		return false;
	}
}
public boolean checkIn(Car car) {
	if(car.getCustomer() != null) {
		
		car.setCustomer(null);
		return true;
	} else {
		return false;
	}
}
public ArrayList<Car> getCarsForCustomer(Customer customer) {
	ArrayList<Car> result = new ArrayList<Car>();
	for(Car aCar : this.getCars()) {
		if((aCar.getCustomer()!=null)&&(aCar.getCustomer().getName().equals(customer.getName()))) {
			result.add(aCar);
		}
	}
	return result;
}
public ArrayList<Car> getAvailableCars() {
	ArrayList<Car> result = new ArrayList<Car>();
	for(Car aCar : this.getCars()) {
		if(aCar.getCustomer() == null) {
			result.add(aCar);
		}
	}
	return result;
}
public ArrayList<Car> getUnavailableCars() {
	ArrayList<Car> result = new ArrayList<Car>();
	for(Car aCar : this.getCars()) {
		if(aCar.getCustomer() != null) {
			result.add(aCar);
		}
	}
	return result;
}
public String toString() {
	return this.getCompanyName()+"의 보유 차량="+this.getCars().size()+"대, 회원수="+this.getCustomers().size()+"명";
}
public void printStatus() {
	System.out.println("---렌트카 현황---\n"+this.toString());
	for(Car aCar : this.getCars()) {
		System.out.println(aCar);
	}
	for(Customer customer : this.getCustomers()) {
		int count = this.getCarsForCustomer(customer).size();
		System.out.println(customer+"은/는"+count+"대 렌트중");
	}
	System.out.println("현재 렌트 가능 차량:"+this.getAvailableCars().size());
	System.out.println("---종료---");
	}
}