package org.javaro.lecture;
public class Customer {
	private String name; private String age;
	public Customer() {}
	public String getName() {
		return this.name;
	}
	public String getAge() {
		return this.age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String toString(){
		return "고객 이름/나이="+this.getName()+"/"+this.getAge();
	}
}