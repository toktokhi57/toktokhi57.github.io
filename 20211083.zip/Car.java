package org.javaro.lecture;
public class Car {
	private String type; private String price; private Customer customer;
	public Car(String type) { this.type = type; }
	public void setType(String type) { this.type = type; }
	public String getType() { return this.type; }
	public void setPrice(String price) { this.price = price; }
	public String getPrice() { return this.price; }
	public void setCustomer(Customer customer) { this.customer = customer; }
	public Customer getCustomer() { return this.customer; }
	public String toString() {
		String available;
		if(this.getCustomer() == null) {
			available = "렌트 가능";
		} else {
			available = "렌트 불가능";
		}
		return "종류="+this.getType()+",가격="+this.getPrice()+","+available;
	}
}